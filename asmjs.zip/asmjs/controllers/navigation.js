
function goToRegister() {
    window.location.href = 'register.html';
}

function goToHome() {
    window.location.href = '../user/index.html';
}

function goToLogin() {
    window.location.href = 'login.html';
}

function goToCart() {
    window.location.href = 'cart.html';
}

